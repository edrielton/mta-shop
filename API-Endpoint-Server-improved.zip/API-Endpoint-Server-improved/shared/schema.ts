import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table with MTA serial/account linking
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  mtaSerial: text("mta_serial"),
  mtaAccount: text("mta_account"),
  isAdmin: boolean("is_admin").default(false),
  isVip: boolean("is_vip").default(false),
  vipExpiresAt: timestamp("vip_expires_at"),
  coinBalance: integer("coin_balance").default(0),
  stripeCustomerId: text("stripe_customer_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Products table (for items not managed by Stripe)
export const products = pgTable("products", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
  sku: text("sku").notNull().unique(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("BRL"),
  category: text("category").notNull(), // vip, vehicle, coins, item, skin
  imageUrl: text("image_url"),
  mtaCommand: text("mta_command").notNull(), // e.g., "giveVip30d", "giveCarID32"
  mtaParams: jsonb("mta_params"), // Additional params for MTA command
  isActive: boolean("is_active").default(true),
  stockQuantity: integer("stock_quantity"), // null = unlimited
  createdAt: timestamp("created_at").defaultNow(),
});

// Transactions/Orders table
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  productId: varchar("product_id").references(() => products.id),
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  stripeCheckoutSessionId: text("stripe_checkout_session_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("BRL"),
  status: text("status").notNull().default("pending"), // pending, processing, completed, failed, refunded
  paymentMethod: text("payment_method"), // stripe, pix, crypto
  mtaActivationStatus: text("mta_activation_status").default("pending"), // pending, success, failed
  mtaActivationError: text("mta_activation_error"),
  mtaActivationAttempts: integer("mta_activation_attempts").default(0),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// System logs table
export const systemLogs = pgTable("system_logs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // payment, webhook, mta_activation, auth, admin, error
  level: text("level").notNull().default("info"), // info, warn, error, debug
  message: text("message").notNull(),
  userId: varchar("user_id").references(() => users.id),
  transactionId: varchar("transaction_id").references(() => transactions.id),
  metadata: jsonb("metadata"),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at").defaultNow(),
});

// MTA Server settings
export const mtaSettings = pgTable("mta_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serverUrl: text("server_url").notNull(),
  serverPort: integer("server_port").notNull().default(22005),
  apiToken: text("api_token").notNull(),
  isActive: boolean("is_active").default(true),
  lastHealthCheck: timestamp("last_health_check"),
  healthStatus: text("health_status").default("unknown"), // online, offline, unknown
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  transactions: many(transactions),
  logs: many(systemLogs),
}));

export const productsRelations = relations(products, ({ many }) => ({
  transactions: many(transactions),
}));

export const transactionsRelations = relations(transactions, ({ one, many }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  product: one(products, {
    fields: [transactions.productId],
    references: [products.id],
  }),
  logs: many(systemLogs),
}));

export const systemLogsRelations = relations(systemLogs, ({ one }) => ({
  user: one(users, {
    fields: [systemLogs.userId],
    references: [users.id],
  }),
  transaction: one(transactions, {
    fields: [systemLogs.transactionId],
    references: [transactions.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  isAdmin: true,
  isVip: true,
  vipExpiresAt: true,
  coinBalance: true,
  stripeCustomerId: true,
});

export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSystemLogSchema = createInsertSchema(systemLogs).omit({
  id: true,
  createdAt: true,
});

export const insertMtaSettingsSchema = createInsertSchema(mtaSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  lastHealthCheck: true,
  healthStatus: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export type InsertSystemLog = z.infer<typeof insertSystemLogSchema>;
export type SystemLog = typeof systemLogs.$inferSelect;

export type InsertMtaSettings = z.infer<typeof insertMtaSettingsSchema>;
export type MtaSettings = typeof mtaSettings.$inferSelect;

// Auth schemas
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  mtaSerial: z.string().optional(),
  mtaAccount: z.string().optional(),
});

export type LoginInput = z.infer<typeof loginSchema>;
export type RegisterInput = z.infer<typeof registerSchema>;
