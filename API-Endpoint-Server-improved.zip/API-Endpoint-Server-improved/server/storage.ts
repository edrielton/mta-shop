import { 
  users, 
  products, 
  transactions, 
  systemLogs, 
  mtaSettings,
  type User, 
  type InsertUser,
  type Product,
  type InsertProduct,
  type Transaction,
  type InsertTransaction,
  type SystemLog,
  type InsertSystemLog,
  type MtaSettings,
  type InsertMtaSettings
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, gte } from "drizzle-orm";
import bcrypt from "bcrypt";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  getUserStats(userId: string): Promise<{ totalPurchases: number; totalSpent: number }>;

  // Products
  getProduct(id: string): Promise<Product | undefined>;
  getProductBySku(sku: string): Promise<Product | undefined>;
  getProducts(options?: { category?: string; active?: boolean; limit?: number }): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, data: Partial<Product>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;

  // Transactions
  getTransaction(id: string): Promise<Transaction | undefined>;
  getTransactionByStripeSession(sessionId: string): Promise<Transaction | undefined>;
  getUserTransactions(userId: string): Promise<Transaction[]>;
  getAllTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, data: Partial<Transaction>): Promise<Transaction | undefined>;

  // System Logs
  createLog(log: InsertSystemLog): Promise<SystemLog>;
  getLogs(options?: { type?: string; limit?: number }): Promise<SystemLog[]>;

  // MTA Settings
  getMtaSettings(): Promise<MtaSettings | undefined>;
  updateMtaSettings(data: Partial<MtaSettings>): Promise<MtaSettings | undefined>;
  createMtaSettings(settings: InsertMtaSettings): Promise<MtaSettings>;

  // Admin stats
  getAdminStats(): Promise<{
    todayRevenue: number;
    pendingOrders: number;
    activeUsers: number;
    failedActivations: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, password: hashedPassword })
      .returning();
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.createdAt));
  }

  async getUserStats(userId: string): Promise<{ totalPurchases: number; totalSpent: number }> {
    const userTxs = await db
      .select()
      .from(transactions)
      .where(and(eq(transactions.userId, userId), eq(transactions.status, "completed")));
    
    const totalSpent = userTxs.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);
    return {
      totalPurchases: userTxs.length,
      totalSpent,
    };
  }

  // Products
  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async getProductBySku(sku: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.sku, sku));
    return product || undefined;
  }

  async getProducts(options?: { category?: string; active?: boolean; limit?: number }): Promise<Product[]> {
    let query = db.select().from(products);
    const conditions = [];
    
    if (options?.active !== undefined) {
      conditions.push(eq(products.isActive, options.active));
    }
    if (options?.category) {
      conditions.push(eq(products.category, options.category));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }
    
    const results = await query.orderBy(desc(products.createdAt)).limit(options?.limit || 100);
    return results;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: string, data: Partial<Product>): Promise<Product | undefined> {
    const [updated] = await db
      .update(products)
      .set(data)
      .where(eq(products.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteProduct(id: string): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return true;
  }

  // Transactions
  async getTransaction(id: string): Promise<Transaction | undefined> {
    const [tx] = await db.select().from(transactions).where(eq(transactions.id, id));
    return tx || undefined;
  }

  async getTransactionByStripeSession(sessionId: string): Promise<Transaction | undefined> {
    const [tx] = await db
      .select()
      .from(transactions)
      .where(eq(transactions.stripeCheckoutSessionId, sessionId));
    return tx || undefined;
  }

  async getUserTransactions(userId: string): Promise<Transaction[]> {
    return db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async getAllTransactions(): Promise<Transaction[]> {
    return db.select().from(transactions).orderBy(desc(transactions.createdAt)).limit(100);
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const [created] = await db.insert(transactions).values(transaction).returning();
    return created;
  }

  async updateTransaction(id: string, data: Partial<Transaction>): Promise<Transaction | undefined> {
    const [updated] = await db
      .update(transactions)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(transactions.id, id))
      .returning();
    return updated || undefined;
  }

  // System Logs
  async createLog(log: InsertSystemLog): Promise<SystemLog> {
    const [created] = await db.insert(systemLogs).values(log).returning();
    return created;
  }

  async getLogs(options?: { type?: string; limit?: number }): Promise<SystemLog[]> {
    let query = db.select().from(systemLogs);
    
    if (options?.type) {
      query = query.where(eq(systemLogs.type, options.type)) as any;
    }
    
    return query.orderBy(desc(systemLogs.createdAt)).limit(options?.limit || 100);
  }

  // MTA Settings
  async getMtaSettings(): Promise<MtaSettings | undefined> {
    const [settings] = await db.select().from(mtaSettings).limit(1);
    return settings || undefined;
  }

  async updateMtaSettings(data: Partial<MtaSettings>): Promise<MtaSettings | undefined> {
    const existing = await this.getMtaSettings();
    if (!existing) return undefined;
    
    const [updated] = await db
      .update(mtaSettings)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(mtaSettings.id, existing.id))
      .returning();
    return updated || undefined;
  }

  async createMtaSettings(settings: InsertMtaSettings): Promise<MtaSettings> {
    const [created] = await db.insert(mtaSettings).values(settings).returning();
    return created;
  }

  // Admin stats
  async getAdminStats(): Promise<{
    todayRevenue: number;
    pendingOrders: number;
    activeUsers: number;
    failedActivations: number;
  }> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayTxs = await db
      .select()
      .from(transactions)
      .where(and(
        gte(transactions.createdAt, today),
        eq(transactions.status, "completed")
      ));

    const pendingTxs = await db
      .select()
      .from(transactions)
      .where(eq(transactions.status, "pending"));

    const allUsers = await db.select().from(users);

    const failedTxs = await db
      .select()
      .from(transactions)
      .where(eq(transactions.mtaActivationStatus, "failed"));

    const todayRevenue = todayTxs.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);

    return {
      todayRevenue,
      pendingOrders: pendingTxs.length,
      activeUsers: allUsers.length,
      failedActivations: failedTxs.length,
    };
  }
}

export const storage = new DatabaseStorage();
